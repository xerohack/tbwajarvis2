<?php $__env->startSection('htmlheader_title'); ?>
	creacion de usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Crear nuevo usuario
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12 col-md-offset-0">

				<!-- Default box -->
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title">Formulario de creación</h3>

						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
								<i class="fa fa-minus"></i></button>
							<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
								<i class="fa fa-times"></i></button>
						</div>
					</div>
					<div class="box-body">
                        <!-- Aqui va el formulario-->

                        <h3>Ingrese los datos para el nuevo usuario</h3>
                        <br>
                        <?php echo Form::open(['route' => 'users.store', 'method' => 'POST']); ?>


                            <div class="form-group">
                                <?php echo Form::label('nombre','NOMBRE'); ?>

                                <?php echo Form::text('nombre', null, ['class' => 'form-control', 'required', 'placeholder' => 'Nombre']); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::label('apellido','Apellido'); ?>

                                <?php echo Form::text('apellido', null, ['class' => 'form-control', 'required', 'placeholder' => 'Apellido']); ?>

                            </div>

                            <div class="form-group">
                                    <?php echo Form::label('rut','Rut'); ?>

                                    <?php echo Form::text('rut', null, ['class' => 'form-control', 'required', 'placeholder' => 'Rut']); ?>

                            </div>

                            <div class="form-group">
                                    <?php echo Form::label('email','E-MAIL'); ?>

                                    <?php echo Form::email('email', null, ['class' => 'form-control', 'required', 'placeholder' => 'E-mail']); ?>

                            </div>

                            <div class="form-group">
                                    <?php echo Form::label('cargo','Cargo'); ?>

                                    <?php echo Form::text('cargo', null, ['class' => 'form-control', 'required', 'placeholder' => 'Cargo']); ?>

                            </div>

                            <div class="form-group">
                                    <?php echo Form::label('rol','Rol'); ?>

                                    <?php echo Form::select('rol', ['administrador' => 'administrador','cliente' => 'cliente'],null, ['class' => 'form-control'] ); ?>

                            </div>

                            <div class="form-group">
                                    <?php echo Form::label('password','Password'); ?>

                                    <?php echo Form::password('password', ['class' => 'form-control', 'required', 'placeholder' => '********']); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::submit('Registrar', ['class' => 'btn btn-primary']); ?>

                            </div>

                        <?php echo Form::close(); ?>

					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/franciscocastro/Desktop/project/tbwa/resources/views/admin/users/create.blade.php ENDPATH**/ ?>