<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        
        <strong>Copyright &copy; 2019 <a href="http://tbwa.cl">TBWA\Frederick</a>.</strong>
    </div>
    <!-- Default to the left -->

</footer>
<?php /**PATH /Users/franciscocastro/Desktop/project/tbwa/resources/views/vendor/adminlte/layouts/partials/footer.blade.php ENDPATH**/ ?>