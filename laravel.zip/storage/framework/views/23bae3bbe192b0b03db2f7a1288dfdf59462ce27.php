<?php $__env->startSection('htmlheader_title'); ?>
	usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Lista de usuarios
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12 col-md-offset-0">

				<!-- Default box -->
				<div class="box">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="box-header with-border">
						<h3 class="box-title">Usuarios</h3>

						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
								<i class="fa fa-minus"></i></button>
							<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
								<i class="fa fa-times"></i></button>
						</div>
					</div>
					<div class="box-body table-responsive">
                        <!-- Aqui va el formulario-->
                        <table class="table table-striped">
                            <thead>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Rut</th>
                                <th>Email</th>
                                <th>Cargo</th>
                                <th>Rol</th>
                                <th>Fecha Registro</th>
                                <th>Acción</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->nombre); ?></td>
                                    <td><?php echo e($user->apellido); ?></td>
                                    <td><?php echo e($user->rut); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->cargo); ?></td>
                                    <td><?php echo e($user->rol); ?></td>
                                    <td><?php echo e($user->created_at); ?></td>
                                <td><a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary fa fa-pencil"></a>
                                    <a href="<?php echo e(route('admin.users.destroy', $user->id)); ?>" class="btn btn-danger fa fa-trash" onclick="return confirm('¿Está seguro que desea eliminar el usuario <?php echo e($user->email); ?>?')"></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                        <?php echo $users->render(); ?>


						<?php echo e(trans('adminlte_lang::message.logged')); ?>. USUARIOS <?php echo e(Auth::user()->nombre); ?>

					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/franciscocastro/Desktop/project/tbwa/resources/views/admin/users/index.blade.php ENDPATH**/ ?>