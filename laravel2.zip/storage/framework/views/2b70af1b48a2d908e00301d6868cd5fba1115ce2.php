<?php $__env->startSection('htmlheader_title'); ?>
	Ordenes de trabajo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Lista de ordenes de trabajo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12 col-md-offset-0">

				<!-- Default box -->
				<div class="box">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="box-header with-border">
						<h3 class="box-title">Ordenes de trabajo</h3>

						<div class="box-tools pull-right">
							<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
								<i class="fa fa-minus"></i></button>
							
						</div>
					</div>
					<div class="box-body table-responsive">
                        <!-- Aqui va el formulario-->
                        <table class="table table-striped text-center">
                            <thead>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Tema</th>
                                <th>Producto</th>
                                <th>Departamento</th>
                                <th>Ejecutivo responsable</th>
                                <th>Estado</th>
                                <th>Fecha ingreso</th>
                                <th>Fecha entrega</th>
                                <th>Acción</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ot->id); ?></td>
                                    <td><?php echo e($ot->cliente); ?></td>
                                    <td><?php echo e($ot->tema); ?></td>
                                    <td><?php echo e($ot->producto); ?></td>
                                    <td><?php echo e($ot->departamento); ?></td>
                                    <td><?php echo e($ot->ejecutivores); ?></td>
                                    <td><?php echo e($ot->estado); ?></td>
                                    <td><?php echo e($ot->created_at); ?></td>
                                    <td><?php echo e($ot->fechaentrega); ?></td>
                                    <td>
                                    <a href="<?php echo e(route('ots.edit', $ot->id)); ?>" class="btn btn-primary fa fa-pencil"></a>
                                    <a href="<?php echo e(route('ots.destroy', $ot->id)); ?>" class="btn btn-danger fa fa-trash" onclick="return confirm('¿Está seguro que desea eliminar la orden de trabajo <?php echo e($ot->id); ?>?')"></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                        <?php echo $ots->render(); ?>


						
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/franciscocastro/Desktop/project/tbwa/resources/views/ot/index.blade.php ENDPATH**/ ?>