<!-- Content Header (Page header) -->
<section class="content-header">
    <h1 style="text-align: center">
        <?php echo $__env->yieldContent('contentheader_title', 'Jarvis TBWA\Frederick'); ?>
        <small><?php echo $__env->yieldContent('contentheader_description'); ?></small>
    </h1>

</section>
<?php /**PATH /Users/franciscocastro/Desktop/project/tbwa/resources/views/vendor/adminlte/layouts/partials/contentheader.blade.php ENDPATH**/ ?>