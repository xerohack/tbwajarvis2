<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ot extends Model
{
    //
}
